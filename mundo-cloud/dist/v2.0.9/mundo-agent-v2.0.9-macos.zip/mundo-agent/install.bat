@echo off
set TARGET=%USERPROFILE%\.hermes\mundo-agent
if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /I /Y "%~dp0*" "%TARGET%"
cd /d "%TARGET%"
python -m venv venv
call venv\Scripts\activate
pip install -r requirements.txt
echo MUNDO Agent installed to %TARGET%
echo Run: python %TARGET%\mundo.py
