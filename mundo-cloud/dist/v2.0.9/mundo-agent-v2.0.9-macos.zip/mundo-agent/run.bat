@echo off
set SCRIPT_DIR=%~dp0
cd /d "%SCRIPT_DIR%"
if exist "venv\Scripts\activate.bat" call venv\Scripts\activate.bat
python mundo.py %*
