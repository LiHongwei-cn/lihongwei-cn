#!/usr/bin/env bash
set -euo pipefail
TARGET="$HOME/.hermes/mundo-agent"
mkdir -p "$TARGET"
cp -r "$(dirname "$0")/"* "$TARGET/"
cd "$TARGET"
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
echo "MUNDO Agent installed to $TARGET"
echo "Run: python3 $TARGET/mundo.py"
