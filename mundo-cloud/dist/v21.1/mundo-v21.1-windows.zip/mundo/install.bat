@echo off
set TARGET=%USERPROFILE%\.hermes\skills\mundo
if not exist "%TARGET%" mkdir "%TARGET%"
copy /Y "%~dp0SKILL.md" "%TARGET%\"
if exist "%~dp0references" xcopy /E /I /Y "%~dp0references" "%TARGET%\references"
echo Mundo installed to %TARGET%
echo Restart Hermes to activate.
