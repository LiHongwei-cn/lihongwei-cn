#!/usr/bin/env bash
set -euo pipefail
TARGET="$HOME/.hermes/skills/mundo"
mkdir -p "$TARGET"
cp -r "$(dirname "$0")/SKILL.md" "$TARGET/"
cp -r "$(dirname "$0")/references" "$TARGET/" 2>/dev/null || true
echo "Mundo installed to $TARGET"
echo "Restart Hermes to activate."
