#!/bin/bash
# MUNDO Agent — macOS 双击启动器
# 双击此文件即可启动蒙多

cd "$HOME/.hermes/mundo-agent"
python3 mundo.py
