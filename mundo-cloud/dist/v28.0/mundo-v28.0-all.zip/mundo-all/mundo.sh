#!/bin/bash
# MUNDO Agent — macOS 启动器
# 蒙多想去哪就去哪！

set -e

MUNDO_HOME="$HOME/.hermes/mundo-agent"
MUNDO_SCRIPT="$MUNDO_HOME/mundo.py"
MUNDO_PORT=8765

# 颜色
GOLD='\033[38;5;178m'
IRON='\033[38;5;243m'
RESET='\033[0m'

show_banner() {
    echo -e "${GOLD}"
    echo "    ╔══════════════════════════════════════════╗"
    echo "    ║         👑 MUNDO — THE EMPEROR          ║"
    echo "    ║         AI 智能编排系统 v24.0.0         ║"
    echo "    ╚══════════════════════════════════════════╝"
    echo -e "${RESET}"
}

start_cli() {
    show_banner
    python3 "$MUNDO_SCRIPT" "$@"
}

start_ui() {
    show_banner
    echo -e "${IRON}启动蒙多宫殿 UI...${RESET}"
    # 用 Python 内置 HTTP 服务器
    open "http://localhost:$MUNDO_PORT"
    cd "$MUNDO_HOME" && python3 -m http.server "$MUNDO_PORT"
}

show_help() {
    show_banner
    echo "用法: mundo [选项]"
    echo ""
    echo "  (无参数)     启动蒙多 CLI 交互模式"
    echo "  -q TEXT      单次查询模式"
    echo "  --ui         启动宫殿 UI 页面"
    echo "  -v           显示版本"
    echo "  -h           显示帮助"
    echo ""
    echo "斜杠命令（在 CLI 模式中使用）:"
    echo "  /help        命令手册"
    echo "  /skills      扫描武器库"
    echo "  /ranks       三省六部制排名"
    echo "  /reason      第一性原理推理"
    echo "  /attack      对抗验证"
    echo "  /claude      委托 Claude Code"
    echo "  /hermes      委托 Hermes Agent"
}

case "${1:-}" in
    -h|--help)
        show_help
        ;;
    --ui)
        start_ui
        ;;
    *)
        start_cli "$@"
        ;;
esac
