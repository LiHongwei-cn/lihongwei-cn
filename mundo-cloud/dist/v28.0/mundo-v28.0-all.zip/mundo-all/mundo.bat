@echo off
REM MUNDO Agent — Windows 启动器
REM 蒙多想去哪就去哪！

set MUNDO_HOME=%USERPROFILE%\.hermes\mundo-agent
set MUNDO_SCRIPT=%MUNDO_HOME%\mundo.py

if "%1"=="--ui" goto :ui
if "%1"=="-h" goto :help
if "%1"=="--help" goto :help

echo.
echo     ╔══════════════════════════════════════════╗
echo     ║         👑 MUNDO — THE EMPEROR          ║
echo     ║         AI 智能编排系统 v24.0.0         ║
echo     ╚══════════════════════════════════════════╝
echo.

python "%MUNDO_SCRIPT%" %*
goto :eof

:ui
echo.
echo     启动蒙多宫殿 UI...
start http://localhost:8765
cd /d "%MUNDO_HOME%"
python -m http.server 8765
goto :eof

:help
echo.
echo     ╔══════════════════════════════════════════╗
echo     ║         👑 MUNDO — THE EMPEROR          ║
echo     ╚══════════════════════════════════════════╝
echo.
echo 用法: mundo [选项]
echo.
echo   (无参数)     启动蒙多 CLI 交互模式
echo   -q TEXT      单次查询模式
echo   --ui         启动宫殿 UI 页面
echo   -v           显示版本
echo   -h           显示帮助
echo.
goto :eof
